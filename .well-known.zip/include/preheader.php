<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Mind Tree Inc.</title>






<!-- ------google font -->
<link rel="preconnect" href="https://fonts.googleapis.com"> 


<!-- ------font awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    


<!-- ------bootstrap css -->
 <link   type="text/css" rel="stylesheet" href="css/bootstrap.min.css">


  <!---------main css-------->
<link rel="stylesheet" type="text/css" href="css/style.css">


<!-- ----- resposive css------ -->
<link href="css/responsive.css" rel="stylesheet" type="text/css"> 

<!---------owl-carousel-------->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.transitions.css">
<!-- =============================jquery========================= -->


 <script src="https://code.jquery.com/jquery-3.5.1.js"></script>



</head>
</html>

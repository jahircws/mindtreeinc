<?php
include "include/preheader.php";
include "include/header.php";
?>

<section class="banner-inner">
<div class="container">
<h3>ONLINE <span class="another-color">VERIFICATION</span></h3>
</div>
</section>






<!-- ==========================================about====================================== -->

<section class="about">
	<div class="container">
		<div class="row">

			<div class="col-md-6">
				<div class="about-details">
					<div class="verification-con">
						<h2>Online Certificate Verification</h2>
						<p>It is now easy and simple to submit certificate verification requests Agencies, companies, and organizations must register Currently, this service is available only to Indian users</p>
					</div>
				</div>

			</div>

			<div class="col-md-6">
				<div class="enroll">
					<h3>Enrolment/Reg. No</h3>
					<input type="text">
					<button type="submit" class="btn-primary">SEARCH</button>
				</div>
			</div>

		</div>
	</div>
</section>
















<?php
include "include/footer.php";
?>



</body>

</html>